export interface Tip {
  _id: string;
  email: string;
  Tips: string;
}

export interface NewTip {
  email: string;
  Tips: string;
}
